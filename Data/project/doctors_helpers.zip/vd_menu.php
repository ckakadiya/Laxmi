<div class="bit-6">
		<div id="left-menu">
			<ul>
				<li class="menu-trigger <?php  if($menu=="new_vd"){echo "active";}?>"><a href="visit_doc_reg.php" class="forms-16" id="c-elements">New</a></li>
				<li class="menu-trigger <?php  if($menu=="search_vd"){echo "active";}?>"><a href="visit_doc_search.php" class="data-16" id="c-typo">Search</a></li>
				<li class="menu-trigger <?php  if($menu=="all_vd"){echo "active";}?>"><a href="visit_doctor.php" class="typography-16" id="c-tables">Show All</a></li>
				<li class="menu-trigger <?php  if($menu=="updel_vd"){echo "active";}?>"><a href="visit_doctor.php" class="edit-16" id="c-typo">Update</a></li>
			
			</ul>
		</div>
</div>
