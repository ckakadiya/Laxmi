<div class="bit-6">
		<div id="left-menu">
			<ul>
				<li class="menu-trigger  <?php if($menu=="newmr"){echo "active";} ?>"><a href="newmr_reg.php" class="forms-16" id="c-elements">New</a></li>
				<li class="menu-trigger <?php if($menu=="search_mr"){echo "active";} ?>"><a href="mr_search.php" class="data-16" id="c-tables">Search</a></li>
	                <li class="menu-trigger <?php if($menu=="allmr"){echo "active";} ?>""><a href="mr_reg.php" class="typography-16" id="c-tables">Show All</a></li>

			<li class="menu-trigger <?php if($menu=="profile"){echo "active";} ?>"" "><a href="mr_reg.php" class="file-16" id="c-tables">Profile</a></li>
			</ul>
		</div>
</div>
