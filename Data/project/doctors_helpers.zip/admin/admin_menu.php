
<div class="bit-6">
		<div id="left-menu">
			<ul>
			<li class="menu-trigger <?php if($menu=="clinic_app"){echo "active";}?>"><a href="clinic_wise_app.php" class="data-16" id="c-gallery">clinic wise appointment</a></li>
            <li class="menu-trigger <?php if($menu=="clinic_access"){echo "active";}?>"><a href="clinic_access.php" class="data-16" id="c-gallery">clinic Access</a></li>
            <li class="menu-trigger <?php if($menu=="access_history"){echo "active";}?>"><a href="access_history.php" class="data-16" id="c-gallery">Clinic Access History</a></li>
            <li class="menu-trigger <?php if($menu=="dieses"){echo "active";}?>"><a href="dieses_report.php" class="data-16" id="c-gallery">Deses wise report</a></li>
			</ul>
	</div>
</div>