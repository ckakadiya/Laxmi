<?php
	$GLOBALS['pcno'] = 10;//patient name compress
	$GLOBALS['ncno'] = 10;//patient notes compress
	$GLOBALS['ecno'] = 10;//All email compress
	$GLOBALS['scno'] = 10;//streat name compress
	
	$GLOBALS['no_row']=10;//no of row display in paging
?>