<div class="bit-6">
		<div id="left-menu">
			<ul>
				<li class="menu-trigger <?php if($menu=="user"){echo "active";}?>">
					<a href="user_profile.php" class="file-16" id="c-tables">User Profile</a>
				</li>
				<li class="menu-trigger <?php if($menu=="client"){echo "active";}?>">
					<a href="clinic_profile.php" class="file-16" id="c-tables">Clinic Profile</a>
				</li>
			</ul>
		</div>
	</div>