<div class="bit-6" style="width:220px;">
		<div id="left-menu">
			<ul>
				<li class="menu-trigger <?php  if($menu=="new_medicine"){echo "active";}?>"><a href="medicine.php" class="forms-16" id="c-elements" >New</a></li>
				<li class="menu-trigger <?php  if($menu=="all_medicine"){echo "active";}?>"><a href="allmedicine.php" class="typography-16" id="c-tables">Show All</a></li>
				<li class="menu-trigger <?php  if($menu=="search_med"){echo "active";}?>"><a href="med_search.php" class="data-16" id="c-tables">Search</a></li>
			</ul>
		</div>
</div>
