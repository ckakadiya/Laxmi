<div class="bit-6">
		<div id="left-menu">
			<ul>
				<li class="menu-trigger <?php if($menu=="rep_incomplete"){echo "active";}?>"><a href="incomplite_profile.php" class="profile-16" id="c-elements">Incomplete Profile</a></li>
				<li class="menu-trigger <?php if($menu=="rep_bwdate"){echo "active";}?>"><a href="patient_bw_dates.php" class="data-16" id="c-typo">Patient Between Date</a></li>
				<li class="menu-trigger <?php if($menu=="rep_disease"){echo "active";}?>"><a href="disease_report.php" class="typography-16" id="c-tables">Disease Report</a></li>
				<li class="menu-trigger <?php if($menu=="rep_pending"){echo "active";}?>"><a href="pending_treat.php" class="widgets-16" id="c-tables">Pending Treatment</a></li>
                
			</ul>
		</div>
	</div>