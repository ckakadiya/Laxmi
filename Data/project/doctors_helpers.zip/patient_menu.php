<div class="bit-6">
		<div id="left-menu">
			<ul>
				<!--<li class="menu-trigger"><a href="../../Doctors helper with design/pt-new.html" class="forms-16" id="c-elements">New</a></li>
-->				<li class="menu-trigger <?php if($menu=="search"){echo "active";} ?>">
				<a href="patient_search.php" class="data-16" id="c-typo">Search</a></li>
				<li class="menu-trigger <?php if($menu=="patient_all"){echo "active";} ?>">
                <a href="show_all_patient.php" class="typography-16" id="c-tables">Show All</a>
                </li>
				<li class="menu-trigger <?php if($menu=="patient_profile"){echo "active";} ?>">
                <a href="patient_profile.php" class="file-16" id="c-tables">Profile</a></li>
			</ul>
		</div>
	</div>
