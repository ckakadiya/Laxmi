<div class="bit-6">
		<div id="left-menu">
			<ul>
			<li class="menu-trigger <?php if($menu=="app_reg"){echo "active";}?>"><a href="appointment_reg.php" class="forms-16" id="c-elements">New</a></li>
				<!--<li class="menu-trigger"><a href="ap-updatedelete.html" class="edit-16" id="c-typo">Update/Delete</a></li>-->
				<li class="menu-trigger <?php if($menu=="app_date"){echo "active";}?>"><a href="appointment_date.php" class="calendar-16" id="c-tables">Show Date-wise</a></li>
				<li class="menu-trigger <?php if($menu=="app_all"){echo "active";}?>"><a href="show_all_appointment.php" class="typography-16" id="c-calendar">Show All</a></li>
				<li class="menu-trigger <?php if($menu=="app_coming"){echo "active";}?>"><a href="upcoming_appointment.php" class="widgets-16" id="c-gallery">Up-coming</a></li>
				<li class="menu-trigger <?php if($menu=="app_today"){echo "active";}?>"><a href="today_appointment.php" class="data-16" id="c-gallery">Today's</a></li>
			</ul>
	</div>
</div>