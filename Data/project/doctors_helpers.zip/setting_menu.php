<div class="bit-6">
		<div id="left-menu">
			<ul>
				<li class="menu-trigger <?php if($menu=="resetpwd"){echo "active";}?>">
					<a href="change_password.php" class="file-16" id="c-tables">Reset Password</a>
				</li>
			</ul>
		</div>
	</div>