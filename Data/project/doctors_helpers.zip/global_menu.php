<div class="bit-6">
		<div id="left-menu">
			<ul>
				<!--<li class="menu-trigger"><a href="../../Doctors helper with design/pt-new.html" class="forms-16" id="c-elements">New</a></li>
-->				<li class="menu-trigger active">
				<a href="global_search.php" class="data-16" id="c-typo">Search</a></li>
				
			</ul>
		</div>
	</div>
