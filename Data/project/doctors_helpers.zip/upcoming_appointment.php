<?php
	session_start();
	
	if(isset($_SESSION['cid']))
	{
		$str="appointment";
		$menu="app_coming";
		$arr_patient['cid']=$_SESSION['cid'];
?>
<html>
	<head><TITLE>Registration Form</TITLE></head>
	<link href="css/c1.css" rel="stylesheet" type="text/css">
	<script src="js/jquery.js" language="JavaScript"></script>
	<script src="js/jq.js" language="JavaScript"></script>
	Oo<LINK type="text/css" href="css/skeleton.css" rel="StyleSheet">
	<LINK type="text/css" href="css/base.css" rel="StyleSheet">
	<LINK type="text/css" href="css/style.css" rel="StyleSheet">
	<LINK type="text/css" href="css/table.css" rel="StyleSheet">
	<LINK type="text/css" href="css/multiselect.css" rel="StyleSheet">
<BODY>
	<?php
		include_once("connect.php");
		include_once("global.php");
		include_once("function.php");
		include_once('paging.php');
	?>
	<?php include_once("header.php");?>
	<div id="container">
<?php include_once("app_menu.php");?>
	
	<?php
	$fdir = $_SERVER['PHP_SELF'];

	include_once("connect.php");
	include_once("function.php");
	include_once('paging.php');
	include_once("global.php");
	if(!isset($_GET['p']))
	{
		 $page=1;
	}
	else
	{
		$page = $_GET['p'];
	}
		
	$sel_res=upcomingAppointment($_SESSION['cid']);
	//print_r($sel_res);
	?>
    <?php
	if(isset($sel_res['id']))
	{
	$lan=count($sel_res['id']);
	$pager=pagedata($GLOBALS['no_row'],$lan,$page);
	$start=$pager['offset'];
	$end=$pager['limit'];
	if($end>$lan)
	{
		$end=$lan;
	}
	}
	?>
	<div class="bit-14">
		<div class="box-element">
			<div class="box-head-light"><span class="widgets-16"></span><h3>Upcoming Appoinment</h3></div>
			<div class="box-content no-padding">
            <?php
			
            if(isset($sel_res['result']))
			{
				?>
	
					<fieldset>
						<table class="i-table fullwidth" >
						<thead>
						<tr>
							<td>Apponiment no</td>
							<td>Patient Name</td>
							<td>Gender</td>
							<td>Phone No</td>
							<td>Date</td>
							<td>Time</td>
							<td>Time Duration</td>
							<td>Notes</td>
						</tr>
						</thead>
						<?php
								$color=0;
								for($i=$start;$i<$end;$i++)
								{
						?>
									
										<tr>
										
						<?php			echo "<td height='35'>".$sel_res['appointment_no'][$i]."</td>";
										echo "<td title='".$sel_res['pname'][$i]."'>".compressDetail($sel_res['pname'][$i],$GLOBALS['pcno'])."</td>";
										echo "<td>".$sel_res['gender'][$i]."</td>";
										echo "<td>".$sel_res['pno'][$i]."</td>";
										echo "<td>".$sel_res['date'][$i]."</td>";
										echo "<td>".$sel_res['time'][$i]."</td>";
										echo "<td>".$sel_res['time_duration'][$i]."</td>";
										echo "<td title='".$sel_res['notes'][$i]."'>".compressDetail($sel_res['notes'][$i],$GLOBALS['ncno'])."</td>";
										echo "</tr>";
										$color++;
								}
						?>
						
				</table>
					<section>
							<div id="datatable_paginate" class="dataTables_paginate paging_full_numbers no-padding">
								
									<span>
										<?php
											page_strip($page,$fdir,$pager);
										?>
									</span>
								
							</div>
							<div class="clearfix"></div>
						</section>
		</fieldset>
			</div>
		</div>
</div>
</div>
	<?php	
	}
	
	else
	{
	?>
</BODY>
</html>
<?php
	echo "<div class='alert-msg info-msg' align='center'>No Upcoming Appointment</div>";
	}
	}
	else
	{
			header("location:login.php");
	}
		
?>
